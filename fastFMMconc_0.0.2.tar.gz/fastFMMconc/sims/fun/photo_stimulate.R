# fLME data simulation #########################################################

# simulate data from fLME - multiple random effects
# AX: changed column name from 'ID' to 'id' to be consistent

# Notes: 
# - The name of the output is hardcoded as "photometry" in 127
# - Make sure `model` and `id` have consistent dimensions

# If not give, X and Z are taken from the model object

photo_stimulate <- function(
  X = NULL, # design matrix
  Z = NULL, # design matrix for random effects
  N = NULL, # target sample size
  include = NULL, # extra data to include
  model, # fLME model object
  fixed_smooth = FALSE, # whether to use smoothed betas for true fixed effects
  id,  # col of id (N x 1 vector)
  resid_var_indep = TRUE, # assume residual variance is indepedent across fn. domain as in paper
  resid_var_subj = TRUE, # calculate error variance in subject-specific fashion as opposed to globally
  resid_var_scale = 1, # scale the error variance
  fixed_effects_draw = FALSE, # if use uncertainty around fixed effects
  fixed_effects_scale = 1, # scale non-intercept of fixed effects
  random_effects_scale = 1, # scale non-intercept random effects
  rand_int = FALSE, # only use a random intecept (0 out and other random effects)
  rand_int_sigma = FALSE, # whether to use random intercept Sigma for random slopes covariance matrix
  ID_level_re = TRUE, # indicates that random effects are subject-level only (do not vary within subject)
  fixed_shift = 0, # amount to shift fixed effect functional coefficient
  fixed_shift_idx = 2, # index of fixed effect coefficient to shift
  fun_covariates = "lick"
) {
  
  # 0. Variable setup ==========================================================
  
  # draw fixed effects
  if (fixed_smooth)   fixed_eff <- model$betaTilde # use non-smoothed betas
  if (!fixed_smooth)  fixed_eff <- model$betaHat  # use smoothed betas
  
  fixed_eff[-1,] <- fixed_eff[-1,] * fixed_effects_scale
  
  # use model-saved design matrix
  if (is.null(X)) 
    X <- model$designmat
  
  # use model-saved design matrix
  if (is.null(Z))   
    Z <- model$Z
  # No. random effect columns
  qq <- ncol(Z[[1]])
  
  # This has to be modified since Z collapses its list
  # AX: This may fail in unusual setups (e.g., the group is nested)
  # Remove the numeric
  Z_cols <- colnames(Z[[1]])
  Z_cols <- gsub("[[:digit:]]+$", "", Z_cols)
  q <- length(unique(Z_cols))
  
  id <- id_orig <- as.numeric(as.factor(id)) # ensure all id are 1:n sequence
  beta <- fixed_eff # initialize true fixed effect vector
  L <- ncol(beta) # dim of function
  p <- nrow(beta) # number of covariates *including intercept*
  
  # sample size
  subjects <- subjects_orig <- sort(unlist(unique(id)))
  n <- length(subjects) # sample size of observed data
  if (is.null(N))    
    N <- n
  
  # order design matrix based on id
  # TODO: Make this robust to removal of rows due to failed impute
  # X <- X[order(id, decreasing = FALSE), ]
  # Z <- lapply(Z, function(x) x[order(id, decreasing = FALSE),])
  
  # 1. Sample id ===============================================================
  
  # draw synthetic subject id from observed id and use the corresponding design matrix
  if (N != n) {
    # subj_samp <- sample(subjects, N, replace = I(N > n) ) # sample subject id
    if (N > n) {
      subj_samp <- sample(subjects, N - n, replace = T) # sample subject id
      subj_samp <- c(subjects, subj_samp)
    } else {
      subj_samp <- sample(subjects, N, replace = F) # sample subject id
    }
    idx_list <- lapply(subjects, function(x) which(id == x)) # find row indices corresponding to each ID
    samp_lst <- lapply(subj_samp, function(x) idx_list[[x]]) # element j has row indices of original dataset to be used for synthetic subject j 
    idx <- do.call(c, samp_lst) # concatenate
    # n <- N
    
    # Common error: Ground truth may differ from the simulation
    # Can happen during simulation runs experimenting with trial_trim
    if (max(idx) > nrow(X[[1]]) | max(idx) > nrow(Z[[1]])) {
      stop(
        "Inconsistency between resampling indices and design matrix.", "\n", 
        "Max sampling index: ", max(idx), "\n", 
        "Number of rows in design matrix: ", nrow(X[[1]]), "\n", 
        "Number of rows in Z: ", nrow(Z[[1]]), "\n", 
        "Check to make sure the ground truth model is fit to the correct data."
      )
    }
    X <- lapply(X, function(x) x[idx, ]) 
    Z <- lapply(Z, function(x) x[idx, ]) 
    
    include <- include[idx, , drop = F]
    # id <- id[idx]
    subjects <- 1:n
    # each row w/ observed source animal
    source_id <- id[idx] 
    # new id just repeated in order because of how samp_lst is structured
    id <- do.call(
      c, 
      sapply(
        seq_along(samp_lst), function(x) rep(x, length(samp_lst[[x]]))  
      ) 
    ) 
    rm(idx)
  } else {
    # if n == N then subj_samp is just the original subjects
    subj_samp <- subjects
    source_id <- id
  }

  # 2. Simulate new data =======================================================
  
 
  Y <- matrix(0, nrow = nrow(X[[1]]), ncol = L) # initialize outcome matrix
  # This should be adjusted for different targets
  colnames(Y) <- paste0("photometry_", 1:L)
  nn <- nrow(X[[1]])
  
  # 2.1 Draw fixed effects -----------------------------------------------------
  
  if (fixed_effects_draw) {
    # draw true fixed effects from distribution that accounts for uncertainty in
    # model estimates provided to simulator
    for (l in 1:p)
      beta[l, ] <- MASS::mvrnorm(
        n = 1, 
        mu = fixed_eff[l, ], 
        Sigma = model$betaHat_var[, , l]
      )
  } else {
    beta <- fixed_eff
  }
  
  # shift fixed effect coefficient up or down
  beta[fixed_shift_idx, ] <- beta[fixed_shift_idx, ] + fixed_shift
  
  # 2.2 Residual variance ------------------------------------------------------
  
  # residual variance across functional domain from lfosr function
  # resid_var <- diag( model$var_random["var.Residual",] ) 
  # --not smoothed use diagonal matrix of residual variance from lfosr function 
  # (so errors will be iid)
  
  # smoothed use diagonal matrix of residual variance from lfosr function 
  # (so errors will be iid)
  resid_var <- diag(as.numeric(model$R)) 
  # this will be replaced below depending on resid_var_indep and resid_var_subj
  resid_cov <- NULL 
  
  # 2.2.1 Non-independent case -----------
  
  if (!resid_var_indep & !resid_var_subj) {
    # if you don't want to assume error are independent across functional domain
    # use residuals to calculate full covariance matrix
    resid_cov <- cov(model$residuals)

    # trim eigenvalues to ensure matrix is PSD
    ## trim non-positive eigenvalues to ensure positive semidefinite
    edcomp <- eigen(resid_cov) 
    eigen.positive <- which(edcomp$values > 0)
    
    if (length(eigen.positive) == qq) {
      # nothing needed here because matrix is already PSD
    } else {
      if (length(eigen.positive) == 0) {
        resid_cov <- tcrossprod(edcomp$vectors[,1]) * edcomp$values[1] 
      } else {
        # sum of outerproducts of eigenvectors scaled by eigenvalues for all 
        # positive eigenvalues
        resid_cov <- Reduce(
          '+', 
          lapply(
            eigen.positive, 
            function(x) 
              tcrossprod(edcomp$vectors[,x]) * edcomp$values[x]
          )
        ) 
      }
    }
    rm(eigen.positive, edcomp)
  } else if (resid_var_indep & !resid_var_subj) {
    resid_cov <- as.numeric(matrixStats::colVars(as.matrix(model$residual)))
    argvals <- 1:L
    # smooth across function
    resid_cov <- diag(as.numeric(smooth.spline(x = argvals, y = resid_cov)$y))
  }
  
  # 2.3 Draw random effects ----------------------------------------------------
  
  # initialize all random effects as 0
  random_effects <- array(0, c(qq, L, nn)) 

  # make sure you are using the right indices of GHat[]
  var_names <- dimnames(model$var_random)[[1]][
    -length(dimnames(model$var_random)[[1]])
  ] 
  var_nm_idx <- grep(paste0("^", "var."), var_names)
  
  # AX: I removed the randint checking for now
  # AX: I assume adding it back will only require pulling the correct G 
  # Which will be var.id.(Intercept)
  
  # Iterate over random effects
  # AX: Double-check: concurrence has no effect here
  for (re in 1:qq) {
    # Sigma is a L x L matrix where L := length of functional domain
    Sigma <- as.matrix(model$G[var_nm_idx[re], , ])
    edcomp <- eigen(Sigma)
    eigen.positive <- which(edcomp$values > 0)
    
    # check to see if we need to trim eigenvalues
    if (length(eigen.positive) == L) {
      # do not need to do anything
    } else if (length(eigen.positive) == 0) {
      Sigma <- tcrossprod(edcomp$vectors[,1]) * edcomp$values[1] 
      # matrix(edcomp$vectors[,1], ncol = 1) %*% edcomp$values[1] %*% matrix(edcomp$vectors[,1], nrow = 1)
    } else {
      # sum of outerproducts of eigenvectors scaled by eigenvalues for all 
      # positive eigenvalues
      Sigma <- Reduce(
        '+', 
        lapply(
          eigen.positive, 
          function(x)  
            tcrossprod(edcomp$vectors[, x]) * edcomp$values[x] 
        )
      ) 
    }

    # draw random effect vector for each RE column of Z 
    # AX: This should be affected by randint, so make sure to adjust in the 
    # future
    # Reminder: nn := nrow(X[[1]])
    Sigma <- Sigma * random_effects_scale
    
    random_effects[re, , ] <- t(
      MASS::mvrnorm(nn, mu = rep(0, L), Sigma = Sigma)
    )  
  }

  # AX: Layered for-loop for concurrent models
  # Outer layer loops over subjects, indexed by i
  # Inner layer loops over functional domain, indexed by l
  for (i in 1:N) {
    # rows corresponding to this subject in new dataset
    idx <- which(id == i) 
    # subject rows of observed data ID (that synthetic ID corresponds to)
    idx_orig <- which(id_orig == subj_samp[i]) 
    beta_i <- beta 

    # # calculate residual variance
    if (!resid_var_indep & resid_var_subj) {
      # use residuals to calculate full covariance matrix 
      # -- assumes non-independent errors across functional domain
      resid_cov <- cov(model$residuals[idx_orig, ])
    } else if (resid_var_indep & resid_var_subj) {
      resid_cov <- as.numeric( 
        matrixStats::colVars(as.matrix(model$residual[idx_orig, ]))
      )
      argvals <- 1:L
      # smooth across function
      resid_cov <- diag(
        as.numeric(smooth.spline(x = argvals, y = resid_cov)$y)
      )
    }
    
    if (is.null(resid_cov)) {
      resid_cov <- diag(as.numeric(resid_var))
      message("Use residual variance")
    }   
    # browser()
    # Error matrix
    eps <- MASS::mvrnorm(
      length(idx), 
      mu = rep(0, L), 
      Sigma = resid_cov * resid_var_scale
    ) 
    
    # Calculate Z_{i, j}^T gamma_{i, j, l} for each i

    if (ID_level_re) {
      # only one random effect draw per animal 
      # (arbitrarily take the first random effect draw)
      # re_i will be an length(idx) x L vector
      re_i <- sapply(
        idx, 
        function(ii) {
          # Second layer: apply over l in L
          sapply(
            1:L, 
            function(l) Z[[l]][ii, ] %*% random_effects[, l, idx[1]]
          )
        }
      )
    } else {
      re_i <- sapply(
        idx, 
        function(ii) {
          # Second layer: apply over l in L
          sapply(
            1:L, 
            function(l) Z[[l]][ii, ] %*% random_effects[, l, ii]
          )
        }
      )
    }
    
    # draw sample of outcome across functional domain for all observations 
    # for subject i

    # 2.4 Fix dimensionality of fixed effects ----------------------------------
    
    X_beta_prod <- do.call(
      rbind, 
      lapply(
        idx, 
        function(ii) { 
          sapply(
            1:L, 
            function(l) X[[l]][ii, ] %*% beta_i[, l]
          )
        }
      )
    )
    
    Y[idx, ] <- X_beta_prod + t(re_i) + eps
  }
  
  # 2.5 Fix data presentation --------------------------------------------------

  conc_idx <- grep(
    paste0("^", paste0(fun_covariates, collapse = "|")), 
    colnames(X[[1]])
  )
  
  # Split the functional and non-func. columns
  X_nonfun <- X[[1]][, -c(1, conc_idx)]
  X_fun <- do.call(cbind, lapply(X, function(x) x[, conc_idx]))
  colnames(X_fun) <- paste0(fun_covariates, "_", 1:ncol(X_fun))
  # Rejoin undummies, nonfunctional, and functional covariates
  X_new <- cbind(X_nonfun, X_fun)
  
  if (is.null(include)) {
    dat <- cbind(id, X_new, Y)
  } else {
    dat <- cbind(id, include, X_new, Y) 
  }
  
  # 3. Return ==================================================================
  
  return( 
    list(
      data = as.data.frame(dat),
      beta = beta,
      random_effects = random_effects,
      source_id = source_id, # indices of observed ID for each row
      subj_samp = subj_samp, # id of sampled subjects
      resid_cov = resid_cov # covariance for error
    )
  )
}

# Save on cluster #############################################

saveFn <- function(file, fileNm, iterNum, save_path = NA) {
  
  if (!is.na(save_path)) {
    # set working directory if specified
    fileNm <- paste0(save_path, "/", fileNm)
  }
  
  # check if file exists
  if (file.exists(fileNm)) {
    # if exists read in file and save this result to correspond to row
    res <- read.csv( fileNm )
    res[iterNum,] <- file[iterNum,]
    write.csv(res, fileNm, row.names = FALSE)
    
  } else {
    # if it does not exist (first iteration to complete) then save resMat
    write.csv(file, fileNm, row.names = FALSE)
  }
  
}

# cluster finder for permutation test -- only significant for certain lengths
cluster_finder <- function(r, min.length = 3) {
  # take in binary vector r and return binary vector that 0s out any sequence of 
  # 1s that is not of at least length min.length
  m <- rep(0, length(r))
  
  runs=rle(r > 0)
  runs.lengths.cumsum = cumsum(runs$lengths)
  myruns = which(runs$values == TRUE & runs$lengths >= min.length)
  ends = runs.lengths.cumsum[myruns]
  
  newindex = ifelse(myruns>1, myruns-1, 0)
  starts = runs.lengths.cumsum[newindex] + 1
  if (0 %in% newindex) starts = c(1,starts)
  
  if (length(starts) > 0) {
    for(x in 1:length(starts)) {  m[seq(starts[x], ends[x])] <- 1 }
  }
  
  return(m)
}


# trim eigenvalues and return PSD matrix
# V is a n x n matrix
eigenval_trim <- function(V) {
  edcomp <- base::eigen(V) ## trim non-positive eigenvalues to ensure positive semidefinite
  eigen.positive <- which(edcomp$values > 0)
  
  if (length(eigen.positive) == ncol(V)) {
    # nothing needed here because matrix is already PSD
  }else if (length(eigen.positive) == 0) {
    V <- tcrossprod(edcomp$vectors[,1]) * edcomp$values[1] 
  } else {
    # sum of outerproducts of eigenvectors scaled by eigenvalues for all positive eigenvalues
    V <- Reduce('+', lapply(eigen.positive, function(x)  tcrossprod(edcomp$vectors[,x]) * edcomp$values[x] ) ) 
  }
  
  return(V)
}

# Modification of cluster saving ##############################

saveFn_new <- function(file, fileNm, iterNum, iters, save_path = NA) {
  
  filePrefix <- paste0(fileNm, "_")
  
  if (!is.na(save_path)) {
    # set working directory if specified
    fileNmIndiv <- paste0(save_path, "/", filePrefix, iterNum)
  }
  
  # save individual file
  write.csv(file[iterNum, ], fileNmIndiv, row.names = FALSE)
  
  fls <- list.files(save_path) # all files
  fls_nms <- grep(paste0("^", filePrefix), fls) # files with names that match
  
  if (length(fls_nms) == iters) {
    # if all have been saved
    
    for(i in 1:iters) {
      ff <- paste0(save_path, "/", filePrefix, i)
      res <- read.csv( ff )
      
      # first one use is file
      if (i == 1) {
        mat <- res
      } else {
        mat[i,] <- res[i,]
      }
      
      setwd(save_path)
      
      base::unlink( paste0(filePrefix, iterNum) ) # delete file
    }
    
    write.csv(mat, fileNm, row.names = FALSE)
    
  }
  
  # # check if file exists
  # if (  file.exists(fileNm)  ) {
  #   # if exists read in file and save this result to correspond to row
  #   res <- read.csv( fileNm )
  #   res[iterNum,] <- file[iterNum,]
  #   write.csv(res, fileNm, row.names = FALSE)
  #   
  # }
}

# Save iterations separately ##################################
