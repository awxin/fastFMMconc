# Removing the zero variance column "lick.50"
conc <- read.csv("data/conc_raw.csv")

# Remove columns where l = 50
conc$photometry.50 <- NULL
conc$lick.50 <- NULL

# Get column indices for functional covariates and rename them
idx <- grep("^lick", colnames(conc))
colnames(conc)[idx] <- paste0("lick_", 1:length(idx))

idx <- grep("^photometry", colnames(conc))
colnames(conc)[idx] <- paste0("photometry_", 1:length(idx))

# Remove rows with missing data
conc <- conc[rowSums(is.na(conc)) == 0, ]

write.csv(conc, "data/conc.csv", row.names = F)
