# Read a ground truth model, simulate a draw, fit a model, then report

# 0 Load and setup #############################################################

# Rstudio mode allows for testing without the command line
rstudio_mode <- F
rstudio_id <- 44
rstudio_params <- "syn_017"

# 0.0 Packages =================================================================

suppressMessages(library(dplyr))

# 0.1 Command-line args ========================================================

args <- commandArgs(TRUE)
iter <- as.integer(as.numeric(args[1]))

if (rstudio_mode) {
  iter <- rstudio_id
}

if (is.na(iter)) {
  stop(
    "Argument `iter` not detected.", "\n",  
    "Please ensure iter and params_id are given as command-line args."
  )
}

params_id <- args[2]

if (rstudio_mode) params_id <- rstudio_params

# 0.2 Directories ==============================================================

# End directories with slash
base_dir <- "" 
# base_dir <- "/data/MLDSST/xinaw/fastFMMsim/"
params_dir <- paste0(base_dir, "params/")
fun_dir <- paste0(base_dir, "fun/")
funsyn_dir <- paste0(base_dir, "syn/")
save_dir <- paste0(base_dir, "raw/")

save_dir <- paste0(save_dir, params_id, '/')
if (!dir.exists(save_dir)) dir.create(save_dir, recursive = T)

# 1 Simulation parameters ######################################################

# 1.1 Consistent across runs ==================================================+

# Testing for existence
params_json <- tryCatch(
  jsonlite::read_json(
    paste0(params_dir, params_id, ".json"), 
    simplifyVector = T
  ), 
  error = function(e) {
    message("Params JSON not found in the specified path.")
    message(paste("Check", params_id, "is in directory", params_dir))
  }
)

res_names <- c(
  "synth_time",
  "fLME_time",
  "beta_CI_joint",
  "beta_CI_joint_noIntrcpt", 
  "beta_CI_joint0", 
  "beta_CI_naive",
  "beta_CI_naive_noIntrcpt",
  "fLME_beta_rmse",
  "fLME_beta_rmse_noIntrcpt",
  "fLME_bias",
  "n_trials",
  "n_ids", 
  "knots_div", 
  "smooth_method",
  "iter"
)

res <- data.frame(matrix(NA, nrow = 1, ncol = length(res_names)))
colnames(res) <- res_names

# 2 Data generation ############################################################

# 2.0 Load functions ===========================================================

# Load function set depending on concurrence
if (params_json$concurrent) {
  source(paste0(fun_dir, "syn_conc.R"))
} else {
  source(paste0(fun_dir, "syn_noconc.R"))
}

source(paste0(funsyn_dir, params_json$syn_functions))
message("Sourcing functions from ", params_json$syn_functions)

# 2.1 Data simulation ==========================================================

set.seed(iter)

timeStart <- Sys.time()
dat_sim <- synthesize_data(
  I = params_json$n_ids, 
  J = params_json$mean_trials, 
  snr_B = params_json$snr_B, 
  snr_sigma = params_json$snr_sigma
)
timeEnd <- Sys.time()
message('Finished synthesizing data.')

res$synth_time <- as.numeric(difftime(timeEnd, timeStart, units = "mins"))

# 3 Fit new model ##############################################################

# number of knots
L <- length(beta_0())
nknots_min <- round(L / params_json$knots_div) 
nknots_min_cov <- round(L / 4)
n <- length(unique(dat_sim$data$id)) 

# fit model and get model CIs
timeStart <- Sys.time()
fit <- fastFMMconc::fui(
  formula = as.formula(params_json$formula), 
  data = dat_sim$data, 
  family = params_json$family, 
  var = params_json$var, 
  analytic = params_json$analytic,
  parallel = params_json$parallel,
  silent = params_json$silent,
  smooth_method = params_json$smooth_method,
  seed = params_json$seed,
  n_cores = params_json$n_cores,
  non_neg = params_json$non_neg,
  MoM = params_json$MoM,
  concurrent = params_json$concurrent
)
timeEnd <- Sys.time()
message('Finished fitting new models.')

res$fLME_time <- as.numeric(difftime(timeEnd, timeStart, units = "mins"))

# 4 Analysis ###################################################################

beta_idx <- 2

# 4.1 Generate 95% CIs =========================================================

# initialize CIs
lower <- upper <- lower.joint <- upper.joint <- matrix(
  NA, nrow = nrow(fit$betaHat), ncol = ncol(fit$betaHat)
) 
joint_incl <- naive_incl <- lower # initialize inclusion indicator matrix
# AX: Check inconsistency with the ground truth
p <- nrow(dat_sim$beta)
if (p != nrow(fit$betaHat)) {
  stop(
    "Fitted design matrix has different structure than the ground truth.", "\n",
    "If the formula is consistent, this may be caused by a factor ", 
    "having a different number of levels."
  )
}


# iterate across regression coefficients, calculate PIs and determine inclusion across fn. domain
for (r in 1:p) {
  # joint CIs
  lower.joint[r, ] <- fit$betaHat[r, ] - 
    fit$qn[r] * sqrt(diag(fit$betaHat_var[, , r]))
  upper.joint[r, ] <- fit$betaHat[r, ] + 
    fit$qn[r] * sqrt(diag(fit$betaHat_var[, , r]))
  
  # check whether estimate in CI
  joint_incl[r, ] <- dat_sim$beta[r, ] <= upper.joint[r, ] &
    dat_sim$beta[r, ] >= lower.joint[r, ]
  
  # naive CIs
  lower[r, ] = fit$betaHat[r, ] - 1.96*sqrt(diag(fit$betaHat_var[, , r]))
  upper[r, ] = fit$betaHat[r, ] + 1.96*sqrt(diag(fit$betaHat_var[, , r]))
  
  # check whether estimate in CI
  naive_incl[r, ] <- dat_sim$beta[r, ] <= upper[r, ] & 
    dat_sim$beta[r, ] >= lower[r, ]
}

# calculate regression coefficient inclusion in 95% CI (across functional domain)
joint_incl <- rowSums(joint_incl) / ncol(joint_incl)
naive_incl <- rowSums(naive_incl) / ncol(naive_incl)

# average CI coverage across regression coefficients
res$beta_CI_joint <- mean(joint_incl)
res$beta_CI_naive <- mean(naive_incl)
res$fLME_beta_rmse <- sqrt(mean((dat_sim$beta - fit$betaHat)^2)) 

res$beta_CI_joint_noIntrcpt <- mean(joint_incl[-1])
res$beta_CI_joint0 <- mean(joint_incl[1])
res$beta_CI_naive_noIntrcpt <- mean(naive_incl[-1])
res$fLME_beta_rmse_noIntrcpt <- sqrt(
  mean((dat_sim$beta[-1, ] - fit$betaHat[-1, ])^2) 
)

# bias of cue term
res$fLME_bias <- mean(
  dat_sim$beta[beta_idx, ] - fit$betaHat[beta_idx, ]
) 

# sample size of sims (i.e., number of trials analyzed)
res$n_trials <- nrow(dat_sim$data)


# 5 Save to CSV ################################################################

# res$run_id <- run_id

# Write run details
res$iter <- iter
res$n_ids <- params_json$n_ids
res$knots_div <- params_json$knots_div
res$smooth_method <- params_json$smooth_method

write.csv(
  do.call(cbind, res), 
  # paste0(save_dir, sprintf("%02d_%04d", run_id, iter), '.csv'),
  paste0(save_dir, sprintf("%04d", iter), '.csv'),
  row.names = F # col.names = F
)