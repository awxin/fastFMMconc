# Sofia 
getwd()

library(fastFMM)
# Load the ggplot2 package
library(ggplot2)
#getwd()
setwd("/Users/sbeas/Documents/R Studio")

dat <- read.csv("GCD2s_RewardZone_Dataset_GA_C.csv")
numCols <- ncol(dat)
colnames(dat) <- c("ID", "Session", "Trial", "Latency", "Trial_order",
                   paste0("photometry.", 1:(numCols - 5)))

# experimental data
sample_hz <- 8
baseline <- 2 # seconds baseline
total_time <- (numCols - 5) / sample_hz
L <- round(numCols - 5)
pre_baseline <- seq(1, baseline * sample_hz)

# convert Session data
dat$Session_orig <- dat$Session 
dat$Session <- ifelse(dat$Session %in% c(20200924, 20190805), 1, dat$Session)
dat$Session <- ifelse(dat$Session %in% c(20200930, 20190807), 2, dat$Session)

# fix trial number
for(i in unique(dat$ID)){
  for(s in dat$Session){
    idx <- which(dat$ID == i & dat$Session == s) 
    if(length(idx) > 0){
      dat$Trial[idx] <- dat$Trial[idx] - min(dat$Trial[idx]) + 1
    }
  }
}

dat$Trial_acc <- NA# culmulative trial number

# fix trial number
for(i in unique(dat$ID)){
  max_trial <- 0
  for(s in 1:2){
    idx <- which(dat$ID == i & dat$Session == s) 
    if(length(idx) > 0){
      dat$Trial_acc[idx] <- dat$Trial[idx] - min(dat$Trial[idx]) + 1 + max_trial
      max_trial <- max(dat$Trial[idx])
    }
  }
}

dat2 <- dat
dat2$earlyLate <- ifelse(dat2$Session_orig == 1, 1, 0)


# fix trial number
for(i in unique(dat$ID)){
  max_trial <- 0
  for(s in 1:2){
    idx <- which(dat2$ID == i & dat2$Session == s) 
    if(length(idx) > 0){
      dat2$Trial_acc[idx] <- dat2$Trial[idx] - min(dat2$Trial[idx]) + 1 + max_trial
      max_trial <- max(dat2$Trial[idx])
    }
  }
}

# removing one missing value in photometry.2
dat <- dat[complete.cases(dat),]

# bin Trial_order
bin_num <- 5
bins <- quantile(dat$Trial_order, probs = seq(0,1, length = bin_num + 1))
bins[1] <- bins[1] - 1 # make it lower than minimum
dat$Time_bin <- cut(dat$Trial_order, 
                breaks = bins, 
                labels = 1:bin_num
                )
dat$Time_bin <- relevel(dat$Time_bin, ref = 1)

# plot
out_index <- grep(paste0("^", "photometry"), names(dat))
plot(colMeans(dat[dat$Time_bin == 1, out_index]), type = "l")
lines(colMeans(dat[dat$Time_bin == 2, out_index]), col = "red")
lines(colMeans(dat[dat$Time_bin == 3, out_index]), col = "grey")
lines(colMeans(dat[dat$Time_bin == 4, out_index]), col = "blue")
lines(colMeans(dat[dat$Time_bin == 5, out_index]), col = "green")

# fit models
mod1 <- fastFMM::fui(photometry ~ Trial_order  +
                       (Trial_order | ID/Session), 
                     data = dat, 
                     var = TRUE, 
                     analytic = TRUE,
                     nknots_min = L / 2,
                     subj_ID = "ID")

colMeans(mod1$aic[-pre_baseline,]) 

# fit model 2
mod2 <- fastFMM::fui(photometry ~ Trial_order  +
                       (Trial_order | ID), 
                     data = dat, 
                     var = TRUE, 
                     analytic = TRUE,
                     nknots_min = L / 2,
                     subj_ID = "ID")

colMeans(mod2$aic[-pre_baseline,]) 


# fit model 3
mod3 <- fastFMM::fui(photometry ~ Trial_order  +
                       (1 | ID), 
                     data = dat, 
                     var = TRUE, 
                     analytic = TRUE,
                     nknots_min = L / 2,
                     subj_ID = "ID")

colMeans(mod3$aic[-pre_baseline,]) 


# fit model 4
mod4 <- fastFMM::fui(photometry ~ Trial_order + Session + 
                       (Trial_order | ID), 
                     data = dat, 
                     var = TRUE, 
                     analytic = TRUE,
                     nknots_min = L / 2,
                     subj_ID = "ID")

colMeans(mod4$aic[-pre_baseline,]) 

# fit model 5
mod5 <- fastFMM::fui(photometry ~ Trial_order * Session + 
                       (Trial_order | ID), 
                     data = dat, 
                     var = TRUE, 
                     analytic = TRUE,
                     nknots_min = L / 2,
                     subj_ID = "ID")

colMeans(mod5$aic[-pre_baseline,]) 

# fit model 6
mod6 <- fastFMM::fui(photometry ~ Trial_order + Session + 
                       (1 | ID/Session), 
                     data = dat, 
                     var = TRUE, 
                     analytic = TRUE,
                     nknots_min = L / 2,
                     subj_ID = "ID")

colMeans(mod6$aic[-pre_baseline,]) 



# compare models
rbind(colMeans(mod1$aic[-pre_baseline,]),
      colMeans(mod2$aic[-pre_baseline,]),
      colMeans(mod3$aic[-pre_baseline,]), 
      colMeans(mod4$aic[-pre_baseline,]),
               colMeans(mod5$aic[-pre_baseline,]),
                        colMeans(mod6$aic[-pre_baseline,]) )

# use model 6 # save this one!
fig <- plot_fui(mod6,
         x_rescale = sample_hz,
         xlab = "Time from Reward Zone Entry (s)",
         title_names = c("Mean on Trial 1, Session 1", "Trial Order Effect", "Session 2 - Session 1 Mean"),
         align_x = baseline)

# save
setwd("/Users/sbeas/Documents/R Studio/FLMM_Results")
ggsave( "GCD2s Reward Aligned in Trial_order.pdf",
        plot = fig,
        width = 8,
        height = 4)
