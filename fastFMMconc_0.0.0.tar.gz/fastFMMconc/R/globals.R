utils::globalVariables(c("lower", "lower.joint", "upper", "upper.joint"))
