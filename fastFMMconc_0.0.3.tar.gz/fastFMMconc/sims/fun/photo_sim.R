# Read a ground truth model, simulate a draw, fit a model, then report

# Notes: 
# - For the concurrent model, dat_sim only has the correct number of sessions 
# when >= 6 IDs are sampled

# 0 Load and setup #############################################################

# AX: Set to T to use args in script instead of command-line
testing_mode <- T
testing_id <- 1
# testing_run <- 1
testing_params <- "kern_01"

# AX: Reminder: results are hard-coded
RES_NCOL <- 86

# 0.0 Packages =================================================================

# if (requireNamespace("renv", quietly = TRUE)) {
#   renv::activate()
# } else {
#   stop("Install 'renv' to load the dependecies.")
# }

# Used enough to warrant library calls
# library(lme4) ## mixed models
# library(refund) ## fpca.face
# library(dplyr) ## organize lapply results
# library(mgcv) ## smoothing in step 2
# library(mvtnorm) ## joint CI
# library(parallel) ## mcapply
# library(Rfast)

suppressMessages(library(dplyr))

# 0.1 Command-line args ========================================================

args <- commandArgs(TRUE)
# run_id <- as.integer(as.numeric(args[1])) 
iter <- as.integer(as.numeric(args[1]))

if (testing_mode) {
  # run_id <- testing_run
  iter <- testing_id
}

# if (is.na(run_id) | is.na(iter)) {
if (is.na(iter)) {
  stop(
    "Argument `iter` not detected.", "\n",  
    "Please ensure iter and params_id are given as command-line args."
  )
}

# seed index from array id

# paths
# params_id <- 'fullx_D'
params_id <- args[2]
if (testing_mode) params_id <- testing_params

# 0.2 Directories ==============================================================

# End directories with slash
base_dir <- "" 
base_dir <- "/data/MLDSST/xinaw/fastFMMsim/"
params_dir <- paste0(base_dir, "params/")
fun_dir <- paste0(base_dir, "fun/")
data_dir <- paste0(base_dir, "data/")
truth_dir <- paste0(base_dir, "truth/")
save_dir <- paste0(base_dir, "raw/")

save_dir <- paste0(save_dir, params_id, '/')
if (!dir.exists(save_dir)) dir.create(save_dir, recursive = T)

# 1 Simulation parameters ######################################################

# 1.1 Consistent across runs ==================================================+

params_json <- tryCatch(
  jsonlite::read_json(
    paste0(params_dir, params_id, ".json"), 
    simplifyVector = T
  ), 
  error = function(e) {
    message("Params JSON not found in the specified path.")
    message(paste("Check", params_id, "is in directory", params_dir))
  }
)

target_Hz <- params_json$target_Hz
knots_div <- params_json$knots_div
# If 1, does every other trial
trial_trim <- params_json$trial_trim
cue_period_length <- params_json$cue_period_length 
resid_scale <- params_json$resid_scale
fixed_shift <- params_json$fixed_shift

# 1.2 Run-specific parameters ==================================================

# Whether to use smoothed coefficients as truth or not
fixed_smooth <- params_json$fixed_smooth
# assume residual variance is indepedent across fn. domain as in paper
resid_var_indep <- params_json$resid_var_indep
# residual variance subject specific or global
resid_var_subj <- params_json$resid_var_subj
n_ids <- params_json$n_ids
fixed_effects_scale <- params_json$fixed_effects_scale
random_effects_scale <- params_json$random_effects_scale

# AX: Ncol is hard-coded
res <- data.frame(matrix(NA, nrow = 1, ncol = RES_NCOL)) 
colnames(res) <- c(
  "beta_CI_joint",
  "beta_CI_naive",
  "fLME_beta_rmse",
  "fLME_time",
  "fLME_avgSignif",
  "fLME_Joint_avgSignif",
  "fLME_avgbeta_rmse",
  "fLME_avgbeta_CI_incl",
  "perm_avgSignif",
  "fLME_bias",
  "LME_avgbeta_rmse",
  "LME_avgbeta_CI_incl",
  "perm_avgSignif_0",
  "perm_avgSignif_2",
  "ttest_avgbeta_rmse",
  "ttest_avgbeta_CI_incl",
  "perm_rmse",
  "perm_CI_incl",
  "beta_CI_joint_noIntrcpt",
  "beta_CI_naive_noIntrcpt",
  "fLME_beta_rmse_noIntrcpt",
  "beta_CI_boot",
  "beta_CI_boot_noIntrcpt",
  "fLME_Maxbeta_CI_incl_boot",
  "fLME_reward_CI_incl_boot",
  "perm_CI_incl_reward",
  "beta_CI_boot_naive",
  "beta_CI_boot_noIntrcpt_naive",
  "pffr_reward_CI_incl",
  "fLME_reward_CI_incl_boot_naive",
  "fLME_bias",
  "fLME_simple_bias",
  "fLME_Boot_avgSignif",
  "fLME_Boot_Joint_avgSignif",
  "fLME_auc_signif",
  "LME_max_signif",
  "LME_auc_signif",
  "ttst_max_signif",
  "ttst_auc_signif",
  "perm_max_signif",
  "perm_auc_signif",
  "fLME_boot_auc_signif_CF",
  "fLME_boot_auc_CI_incl",
  "fLME_boot_auc_signif",
  "fLME_orig_time",
  "fLME_sim_time",
  "fLME_boot_time",
  "n_trials",
  "perm_avgbeta_rmse",
  "perm_avgbeta_CI_incl",
  "perm_avgSignif_1",
  "pffr_avgSignif",
  "fLME_boot_auc_unCorrect_signif",
  "fLME_avgbeta_CI_incl_boot_unCorrect",
  "pffr_CI_joint",
  "pffr_beta_rmse",
  "pffr_time",
  "pffr_CI_joint_noIntrcpt",
  "pffr_beta_rmse_noIntrcpt",
  "pffr_bias_noIntrcpt",
  "pffr_avgbeta_CI_incl",
  "pffr_auc_signif",
  "pffr_avgbeta_rmse",
  "beta_CI_joint0",
  "beta_CI_boot_joint0",
  "pffr_CI_joint0",
  "fLME_reward_avgCIs",
  "fLME_reward_joint_avgCIs",
  rep("NA", 14), 
  # "run_id", 
  "n_ids", 
  "knots_div", 
  "smooth_method",
  "iter"
)

# extra name for sample size corrected bootstrap CIs
bootstrap_nms <- c(
  25, 30, 22, 27, 23, 65, 28, 33, 34, 44, 53, 42, 43, 54
)
names(res)[69:82] <- paste0(
  names(res)[bootstrap_nms], "_ss"
)

# 1.3 Original data variables ==================================================

# day when cue duration changes
# c('HJ-FP-M2','HJ-FP-M3','HJ-FP-M4','HJ-FP-M6','HJ-FP-M7', 'HJ-FP-F1','HJ-FP-F2')
mouseList <- c(
  'HJ-FP-M2',
  'HJ-FP-M3',
  'HJ-FP-M4',
  'HJ-FP-F1',
  'HJ-FP-F2',
  'HJ-FP-M6',
  'HJ-FP-M7'
) 
# last day of each condition
session_max <- c(32, 27, 37, 22, 27, 22, 23) 
# c(29, 24, 32, 19, 20, 19, 24)
cue_change <- c(29, 24, 32, 19, 24, 19, 20) 
# c(15, 15, 16, 15, 16, 16, 15)
csPlus_vec <- c(15, 15, 16, 16, 15, 15, 16) 
cue_mat <- as.data.frame(cbind(mouseList, cue_change, csPlus_vec))
colnames(cue_mat) <- c("id", "day", "cs")
# cbind(dat$eventlog$nonsolenoidflag, dat$eventlog$eventtime, dat$eventlog$eventindex)

n <- length(mouseList)
preSessions <- 3 # number of days before change day
session_min <- cue_change - (preSessions + 1) # assumes this folder only has files we need
pre_min_tm <- 1 # pre_lick period
post_min_tm <- 5 # post lick period
aic_period_length <- 5 # used for AIC
trial_num <- 100 # trials per session

reward_period <- seq(
  pre_min_tm * target_Hz + 1, 
  cue_period_length * target_Hz
)  # reward period used in paper

# samples before after
Hz <- 1 / 0.008
pre_samps <- round(pre_min_tm * Hz) # samples before lick
post_samps <- round(post_min_tm * Hz) # samples after lick

# 1.4 Data and function setup ==================================================

dat <- read.csv(paste0(data_dir, params_json$data_fname))
dat$session <- as.factor(dat$session)

# trial trim to reduce computational burden
trls_reduced <- unique(dat$trial)[
  as.integer(
    round(seq(1, length(unique(dat$trial)), by = trial_trim))
  )
]
dat <- dat[dat$trial %in% trls_reduced, ] # reduce number of trials analzed
dat$id <- as.numeric(as.factor(dat$id)) # make 1:n

# number of knots
L <- ncol(dat[, (grep(paste0("^", "photometry"), colnames(dat)))])
nknots_min <- round(L / knots_div) # L approx. 100
nknots_min_cov <- round(L / 4)
# order data
dat_photo <- dat[order(dat$id, dat$session, dat$trial, decreasing = FALSE), ]
# number of subjects in (potentially) reduced sample
n <- length(unique(dat_photo$id)) 
# important for stability of model
dat_photo$trial <- scale(dat_photo$trial) 

# 2 Data generation ############################################################

# 2.0 Load functions ===========================================================

# Load function set depending on concurrence
if (params_json$concurrent) {
  source(paste0(fun_dir, "sim_conc.R"))
} else {
  source(paste0(fun_dir, "sim_noconc.R"))
}
  
# 2.1 Ground truth model =======================================================

timeStart <- Sys.time()
fit <- readRDS(paste0(truth_dir, params_json$truth_fname))
timeEnd <- Sys.time()

res$fLME_orig_time <- as.numeric(
  difftime(timeEnd, timeStart, units = "mins")
)
p <- nrow(fit$betaHat)

# 2.2 Data simulation ==========================================================

set.seed(iter)
# this corresponds to cue effect 
# --only evaluate performance of models on these to make comparable with t-tests
beta_idx <- 2 

dat_sim <- photo_stimulate(
  X = NULL, # design matrix
  Z = NULL,
  include = dat_photo["session"],
  N = n_ids,
  model = fit, # fLME model object
  # whether to use smoothed betas for true fixed effects
  fixed_smooth = fixed_smooth, 
  # col of IDs (N x 1 vector)
  id = dat_photo$id, 
  # assume residual variance is indepedent across fn. domain as in paper
  resid_var_indep = resid_var_indep, 
  # calculate error variance in subject-specific fashion as opposed to globally
  resid_var_subj = resid_var_subj, 
  resid_var_scale = 1,
  fixed_effects_draw = FALSE,
  fixed_effects_scale = fixed_effects_scale,
  random_effects_scale = random_effects_scale,
  rand_int = rand_int, 
  rand_int_sigma = FALSE,
  # indicates that random effects are subject-level only (no var w/in subject)
  ID_level_re = TRUE, 
  # amount to shift fixed effect functional coefficient
  fixed_shift = fixed_shift, 
  fixed_shift_idx = 2
)

# AX: Checks for the distribution of session
# print(unique(dat_sim$data$session))

# 3 Fit new model ##############################################################

# Process similar to original ground truth
# This may need to be edited depending on the formula being fit
# dat_sim$data <- dat_sim$data %>%
#   # mutate(session = as.factor(session)) %>%
#   select(
#     -session2:-session11
#   ) %>%
#   arrange(id, session, decreasing = FALSE) %>%
#   as.data.frame()

# number of knots
L <- ncol(
  dat_sim$data[, (grep(paste0("^", "photometry"), colnames(dat_sim$data)))]
)
nknots_min <- round(L / knots_div) # L = 100
nknots_min_cov <- round(L / 4)
# number of subjects in (potentially) reduced sample
n <- length(unique(dat_sim$data$id)) 

# fit model and get model CIs
timeStart <- Sys.time()
fit <- fastFMMconc::fui(
  formula = as.formula(params_json$formula), 
  data = dat_sim$data, 
  family = params_json$family, 
  var = params_json$var, 
  analytic = params_json$analytic,
  parallel = params_json$parallel,
  silent = params_json$silent,
  smooth_method = params_json$smooth_method,
  seed = params_json$seed,
  n_cores = params_json$n_cores,
  non_neg = params_json$non_neg,
  MoM = params_json$MoM,
  concurrent = params_json$concurrent #, 
  # design_mat = T, 
  # residuals = T
)
timeEnd <- Sys.time()
message('Finished fitting new models.')

res$fLME_time <- as.numeric(difftime(timeEnd, timeStart, units = "mins"))

# 4 Analysis ###################################################################

# 4.1 Generate 95% CIs =========================================================

# initialize CIs
lower <- upper <- lower.joint <- upper.joint <- matrix(
  NA, nrow = nrow(fit$betaHat), ncol = ncol(fit$betaHat)
) 
joint_incl <- naive_incl <- lower # initialize inclusion indicator matrix
# AX: Check inconsistency with the ground truth
if (p != nrow(fit$betaHat)) {
  stop(
    "Fitted design matrix has different structure than the ground truth.", "\n",
    "If the formula is consistent, this may be caused by a factor ", 
    "having a different number of levels."
  )
}


# iterate across regression coefficients, calculate PIs and determine inclusion across fn. domain
for (r in 1:p) {
  # joint CIs
  lower.joint[r, ] <- fit$betaHat[r, ] - 
    fit$qn[r] * sqrt(diag(fit$betaHat_var[, , r]))
  upper.joint[r, ] <- fit$betaHat[r, ] + 
    fit$qn[r] * sqrt(diag(fit$betaHat_var[, , r]))
  
  # check whether estimate in CI
  joint_incl[r, ] <- dat_sim$beta[r, ] <= upper.joint[r, ] &
    dat_sim$beta[r, ] >= lower.joint[r, ]
  
  # naive CIs
  lower[r, ] = fit$betaHat[r, ] - 1.96*sqrt(diag(fit$betaHat_var[, , r]))
  upper[r, ] = fit$betaHat[r, ] + 1.96*sqrt(diag(fit$betaHat_var[, , r]))
  
  # check whether estimate in CI
  naive_incl[r, ] <- dat_sim$beta[r, ] <= upper[r, ] & 
    dat_sim$beta[r, ] >= lower[r, ]
}

# average of CI inclusion over reward period
# whether pointwise CI contains estimate
res$fLME_reward_avgCIs <- mean(naive_incl[beta_idx, reward_period])  
# whether joint CI contains estimate
res$fLME_reward_joint_avgCIs <- mean(joint_incl[beta_idx, reward_period])  

# calculate regression coefficient inclusion in 95% CI (across functional domain)
joint_incl <- rowSums(joint_incl) / ncol(joint_incl)
naive_incl <- rowSums(naive_incl) / ncol(naive_incl)

# average CI coverage across regression coefficients
res$beta_CI_joint <- mean(joint_incl)
res$beta_CI_naive <- mean(naive_incl)
res$fLME_beta_rmse <- sqrt(mean((dat_sim$beta - fit$betaHat)^2)) 

res$beta_CI_joint_noIntrcpt <- mean(joint_incl[-1])
res$beta_CI_joint0 <- mean(joint_incl[1])
res$beta_CI_naive_noIntrcpt <- mean(naive_incl[-1])
res$fLME_beta_rmse_noIntrcpt <- sqrt(
  mean((dat_sim$beta[-1, ] - fit$betaHat[-1, ])^2) 
)
# bias of cue term
res$fLME_bias <- mean(
  dat_sim$beta[beta_idx, ] - fit$betaHat[beta_idx, ]
) 

# average of significance
res$fLME_avgSignif <- mean(
  1 * I(upper[beta_idx, reward_period] * lower[beta_idx, reward_period] > 0) 
)
res$fLME_Joint_avgSignif <- mean( 
  1 * I(
    upper.joint[beta_idx, reward_period] * 
      lower.joint[beta_idx, reward_period] > 0
  )
)
# sample size of sims (i.e., number of trials analyzed)
res$n_trials <- nrow(dat_sim$data)

# 3.2 Summary statistics ======================================

# Summary statistics for cue analysis with linear models

if (params_json$comparison_methods) {
  photo_indices <- grep(paste0("^", "photometry"), colnames(dat_sim$data))
  Y <- dat_sim$data[, photo_indices] # photometry data
  
  # find summary stats in simulated data
  # peak amplitude starting at cue onset
  peak_ampl <- apply(Y[, reward_period], 1, max) 
  # time point of amplitude starting at cue onset
  peak_time <- apply(Y[, reward_period], 1, which.max) / target_Hz 
  # average signal during cue
  avg_signal <- rowMeans(Y[, reward_period])
  
  # concatenate data
  dat_ss <- cbind(
    dat_sim$data[c("id", "cue")],
    peak_ampl, 
    peak_time, 
    avg_signal
  )
  
  # 3.2.1 LME for summary statistics --------------------------
  
  # lme for average amplitude (use nlme for p-values): 
  # estimates identical with lmer (lme4) and lme(nlme))
  mod_auc <- nlme::lme(
    avg_signal ~ cue,
    random = ~cue | ID,
    data = dat_ss,
    control = lmeControl(
      maxIter = 5000,
      msMaxIter = 5000,
      niterEM = 5000
    )
  )
  
  # 3.2.2 Paired-samp t test of avg summary statistics --------
  
  # message(unique(dat_ss_anova$cue))
  # average summary stats
  # average within animal across trials
  dat_ss_anova <- dat_ss %>% 
    as_tibble() %>%
    group_by(ID, cue) %>%
    summarise(
      peak_ampl_mean = mean(peak_ampl),
      avg_ampl_mean = mean(avg_signal)
    ) %>%
    as.data.frame() %>%
    ungroup() # Only for buggy t.test
  
  # AX: t.test
  
  # t_test_auc <- t.test(formula = avg_ampl_mean ~ cue,
  #                      data = dat_ss_anova,
  #                      alternative = "two.sided",
  #                      mu = 0,
  #                      paired = TRUE,
  #                      conf.level = 0.95)
  
  # Currently t.test is refusing to use paired with formula
  # Manually set the x and y for comparison
  # Try R/4.2.2 ?
  
  t_test_auc <- t.test(
    x = dat_ss_anova$avg_ampl_mean[dat_ss_anova$cue == 0], 
    y = dat_ss_anova$avg_ampl_mean[dat_ss_anova$cue == 1], 
    alternative = 'two.sided', 
    mu = 0, 
    paired = TRUE, 
    conf.level = 0.95
  )
  
  # 3.2.3 Summary stats comparison ----------------------------
  
  # *** functional LME ***
  # RMSE for fLME mean difference
  # average beta for cue difference
  beta_avg <- mean(dat_sim$beta[beta_idx, reward_period]) 
  res[1, 7] <- sqrt(
    mean(
      (beta_avg - mean(fit$betaHat[beta_idx, reward_period])) ^ 2
    )
  )
  
  # variance of average
  len <- rep(1 / length(reward_period), length(reward_period))
  V <- fit$betaHat_var[reward_period, reward_period,beta_idx]
  V <- eigenval_trim(V)   # trim eigenvalues to ensure matrix is PSD
  avg_var <- t(len) %*% V %*% len
  
  # significance of auc
  avg_up <- mean(fit$betaHat[beta_idx, reward_period]) + 1.96 * sqrt(avg_var)
  avg_low <- mean(fit$betaHat[beta_idx, reward_period]) - 1.96 * sqrt(avg_var)
  
  # closed form expression
  res[1, 35] <- 1 * I(avg_up * avg_low > 0) # if upper and lower CIs are either both positive or negative, then doesn't contain 0 so significant
  res[1, 8] <- mean( I( beta_avg <= avg_up) & beta_avg >= mean(avg_low) )  # whether CI contains estimate
  
  # RMSE for non-functional LME mean difference
  beta_avg <- mean( dat_sim$beta[beta_idx, reward_period] ) # average beta for cue difference
  res[1, 11] <- sqrt( mean( (beta_avg - mod_auc$coefficients$fixed[beta_idx] )^2) )
  peak_upper <- mod_auc$coefficients$fixed[beta_idx] + 1.96 * summary(mod_auc)$tTable[,2]
  peak_lower <- mod_auc$coefficients$fixed[beta_idx] - 1.96 * summary(mod_auc)$tTable[,2]
  res[1, 12] <- mean( I( beta_avg <= peak_upper & beta_avg >= peak_lower) ) # whether CI contains estimate
  res[1, 37] <- I(summary(mod_auc)$tTable[beta_idx, 5] <= 0.05)# p-value
  rm(beta_avg, V)
  
  # mean difference t-test
  beta_avg <- mean( dat_sim$beta[beta_idx, reward_period] ) # average beta for cue difference
  res[1, 15] <- sqrt( mean( (beta_avg - t_test_auc$estimate )^2) )
  peak_upper <- t_test_auc$conf.int[2]
  peak_lower <- t_test_auc$conf.int[1]
  res[1, 16] <- mean( I( beta_avg <= peak_upper & beta_avg >= peak_lower) ) # whether CI contains estimate
  res[1, 39] <- I(t_test_auc$p.value <= 0.05)
  rm(beta_avg)
  
  # 3.2.4 Permutation test ------------------------------------
  
  # compare over entire trial (including baseline/pre-cue)
  perm_reward_period_idx <- photo_indices #[seq(pre_min_tm * target_Hz + 1, length(photo_indices) )] # indices acounting for non-photometry variables (e.g., ID, cue)
  L <- length(perm_reward_period_idx)
  perm_mat <- matrix(nrow = boots, ncol = L)
  perm_vec <- vector(length = boots)
  ids_samp <- unique(dat_sim$data$ID)
  n <- length(ids_samp)
  cue_vals <- unique(dat_sim$data$cue)
  idx_list <- lapply(ids_samp, function(x) which(dat_sim$data$ID == x))
  
  for(j in 1:boots){
    samp <- sample.int(n, size = n, replace = TRUE)
    idx <- do.call(c, lapply(1:n, function(x) idx_list[[samp[x]]]))
    d <- dat_sim$data[idx, ]
    perm_mat[j, ] <- colMeans(d[d$cue == cue_vals[2], perm_reward_period_idx]) -
      colMeans(d[d$cue == cue_vals[1], perm_reward_period_idx])
    
    perm_vec[j] <- mean(perm_mat[j,reward_period])
  }
  
  rm(d, idx, samp, idx_list, ids_samp)
  
  # CIs
  d <- dat_sim$data
  beta_perm <- colMeans(as.matrix(d[d$cue == cue_vals[2], perm_reward_period_idx])) -
    colMeans(as.matrix(d[d$cue == cue_vals[1], perm_reward_period_idx])) # average difference
  perm_CIs <- apply(perm_mat, 2, function(x) quantile(x, probs = c(0.025, 0.975)) ) #matrixStats::colSds(perm_mat)
  perm_low <- perm_CIs[1, ] * sqrt(n / (n-1))
  perm_up <- perm_CIs[2, ] * sqrt(n / (n-1))
  
  res[1, 17] <- sqrt( mean( (dat_sim$beta[beta_idx, ] - beta_perm )^2) )
  res[1, 18] <- mean( I(dat_sim$beta[beta_idx, ] <= perm_up &
                              dat_sim$beta[beta_idx, ] >= perm_low) ) # whether CI contains estimate
  res[1, 26] <- mean( I(dat_sim$beta[beta_idx,reward_period] <= perm_up[reward_period] &
                              dat_sim$beta[beta_idx,reward_period] >= perm_low[reward_period] ) ) # whether CI contains estimate over reward period
  
  
  # mean difference
  beta_avg <- mean( dat_sim$beta[beta_idx, reward_period] ) # average beta for cue difference
  mean_diff <- mean(as.matrix(d[d$cue == cue_vals[2], perm_reward_period_idx])) -
    mean(as.matrix(d[d$cue == cue_vals[1], perm_reward_period_idx]))
  auc_up <- quantile(perm_vec, probs = c(0.025, 0.975))[2] * sqrt(n / (n-1))
  auc_low <- quantile(perm_vec, probs = c(0.025, 0.975))[1] * sqrt(n / (n-1))
  res[1, 49] <- sqrt( mean(  (beta_avg - mean_diff )^2) )
  res[1, 50] <- mean( I( beta_avg <= auc_up & beta_avg >= auc_low ) )  # whether CI contains estimate
  
  # significance of auc
  res[1, 41] <- 1 * I(auc_up * auc_low > 0) # if upper and lower CIs are either both positive or negative, then doesn't contain 0 so significant
  
  # average of significance
  perm_signif_vec <- 1 * I(perm_up[reward_period] * perm_low[reward_period] > 0)
  res[1, 13] <- mean(perm_signif_vec) # naive without correction of consecutive threshold
  res[1, 9] <-  mean( cluster_finder(r = perm_signif_vec, min.length = round(target_Hz/4)) ) # consecutive threshold
  res[1, 14] <- mean( cluster_finder(r = perm_signif_vec, min.length = round(target_Hz/2)) ) # consecutive threshold
  res[1, 51] <- mean( cluster_finder(r = perm_signif_vec, min.length = round(target_Hz)) ) # consecutive threshold
  rm(d)
  
  # 4 Bootstrap fLME ##########################################
  
  # AX: Currently not being run 
  
  rm(fit)
  
  # 4.1 Fit model to simulated data ===========================
  
  if (flme_boot) {
    set.seed(1)
    num_boots <- 1000
    # fit model and get model CIs
    timeStart <- Sys.time()
    fit_boot <- fui_fullx(
      as.formula(fun_formula),
      data = dat_sim$data,
      family = "gaussian",
      var = TRUE,
      parallel = run_parallel,
      silent = TRUE,
      analytic = FALSE,
      nknots_min = nknots_min,
      nknots_min_cov = nknots_min_cov,
      smooth_method = "GCV.Cp",
      splines = "tp",
      design_mat = FALSE,
      subj_ID = "id",
      boot_type = "reb",
      num_boots = num_boots,
      num_cores = num_cores
    )
    timeEnd <- Sys.time()
    
    res[1,47] <- as.numeric(difftime(timeEnd, timeStart, units = "mins"))
    
    # 4.2 Generate 95% CIs ====================================
    
    lower <- upper <- lower.joint <- upper.joint <- matrix(NA, nrow = nrow(fit_boot$betaHat), ncol = ncol(fit_boot$betaHat)) # initialize CIs
    joint_incl <- naive_incl <- lower # initialize inclusion indicator matrix
    lower.avg <- upper.avg <- lower # CIs for averaging
    
    # iterate across regression coefficients, calculate PIs and determine inclusion across fn. domain
    for(r in 1:p){
      # joint CIs
      lower.joint[r, ] = fit_boot$betaHat[r, ] - fit_boot$qn[r]*sqrt(diag(fit_boot$betaHat_var[, ,r]))
      upper.joint[r, ] = fit_boot$betaHat[r, ] + fit_boot$qn[r]*sqrt(diag(fit_boot$betaHat_var[, ,r]))
      
      # check whether estimate in CI
      joint_incl[r, ] <- dat_sim$beta[r, ] <= upper.joint[r, ] & dat_sim$beta[r, ] >= lower.joint[r, ]
      
      # naive CIs
      lower[r, ] = fit_boot$betaHat[r, ] - 1.96*sqrt(diag(fit_boot$betaHat_var[, ,r]))
      upper[r, ] = fit_boot$betaHat[r, ] + 1.96*sqrt(diag(fit_boot$betaHat_var[, ,r]))
      
      # naive CIs for averaging (remove the multiplying the variance by 1.2 correction for correlation)
      lower.avg[r, ] = fit_boot$betaHat[r, ] - 1.96*sqrt(diag(fit_boot$betaHat_var[, ,r]) / 1.2)
      upper.avg[r, ] = fit_boot$betaHat[r, ] + 1.96*sqrt(diag(fit_boot$betaHat_var[, ,r]) / 1.2)
      
      # check whether estimate in CI
      naive_incl[r, ] <- dat_sim$beta[r, ] <= upper[r, ] & dat_sim$beta[r, ] >= lower[r, ]
    }
    
    # average of CI inclusion over reward period
    res[1, 25] <- mean( joint_incl[beta_idx, reward_period] )  # whether joint CI contains estimate
    res[1, 30] <- mean( naive_incl[beta_idx, reward_period] )  # whether pointwise CI contains estimate
    
    # calculate regression coefficient inclusion in 95% CI (across functional domain)
    joint_incl <- rowSums(joint_incl) / ncol(joint_incl)
    naive_incl <- rowSums(naive_incl) / ncol(naive_incl)
    
    # average CI coverage across regression coefficients
    res[1, 22] <- mean(joint_incl)
    res[1, 27] <- mean(naive_incl)
    
    # don't evaluate performance on intercept (so only cue effect here since one covariate)
    res[1,23] <- mean(joint_incl[-1])
    res[1,65] <- mean(joint_incl[1])
    res[1,28] <- mean(naive_incl[-1])
    
    # average of significance
    res[1, 33] <- mean( 1 * I(upper[beta_idx, reward_period] * lower[beta_idx, reward_period] > 0) )
    res[1, 34] <- mean( 1 * I(upper.joint[beta_idx, reward_period] * lower.joint[beta_idx, reward_period] > 0) )
    
    # significance of AUC
    res[1, 44] <- 1 * I(mean(upper[beta_idx, reward_period]) * mean(lower[beta_idx, reward_period]) > 0) # if upper and lower CIs are either both positive or negative, then doesn't contain 0 so significant
    res[1, 53] <- 1 * I(mean(upper.avg[beta_idx, reward_period]) * mean(lower.avg[beta_idx, reward_period]) > 0) # if upper and lower CIs are either both positive or negative, then doesn't contain 0 so significant
    
    # closed form expression for variance of average of betas
    len <- rep(1/length(reward_period), length(reward_period))
    V <- fit_boot$betaHat_var[reward_period,reward_period,beta_idx]
    V <- eigenval_trim(V)   # trim eigenvalues to ensure matrix is PSD
    avg_var <- t(len) %*% V %*% len
    # CIs
    avg_up <- mean(fit_boot$betaHat[beta_idx, reward_period]) + 1.96 * sqrt(avg_var)
    avg_low <- mean(fit_boot$betaHat[beta_idx, reward_period]) - 1.96 * sqrt(avg_var)
    # significance of average
    res[1, 42] <- 1 * I(avg_up * avg_low > 0) # if upper and lower CIs are either both positive or negative, then doesn't contain 0 so significant
    res[1, 43] <- mean( I( beta_avg <= avg_up) & beta_avg >= mean(avg_low) )  # whether CI contains estimate
    
    # AUC beta
    beta_avg <- mean( dat_sim$beta[beta_idx, reward_period] ) # average beta for cue difference
    res[1, 54] <- mean( I( beta_avg <= mean(upper.avg[beta_idx, reward_period]) & beta_avg >= mean(lower.avg[beta_idx, reward_period]) ) ) # whether CI contains estimate
    
    rm(beta_avg)
    
    # 4.3 95% CIs with sample size correction =================
    
    lower <- upper <- lower.joint <- upper.joint <- matrix(NA, nrow = nrow(fit_boot$betaHat), ncol = ncol(fit_boot$betaHat)) # initialize CIs
    joint_incl <- naive_incl <- lower # initialize inclusion indicator matrix
    lower.avg <- upper.avg <- lower # CIs for averaging
    n <- length(unique(dat_sim$data$ID))
    
    # iterate across regression coefficients, calculate PIs and determine inclusion across fn. domain
    for(r in 1:p){
      # joint CIs
      lower.joint[r, ] = fit_boot$betaHat[r, ] - fit_boot$qn[r]*sqrt(diag(fit_boot$betaHat_var[, ,r])) * sqrt(n / (n-1))
      upper.joint[r, ] = fit_boot$betaHat[r, ] + fit_boot$qn[r]*sqrt(diag(fit_boot$betaHat_var[, ,r])) * sqrt(n / (n-1))
      
      # check whether estimate in CI
      joint_incl[r, ] <- dat_sim$beta[r, ] <= upper.joint[r, ] & dat_sim$beta[r, ] >= lower.joint[r, ]
      
      # naive CIs
      lower[r, ] = fit_boot$betaHat[r, ] - 1.96*sqrt(diag(fit_boot$betaHat_var[, ,r])) * sqrt(n / (n-1))
      upper[r, ] = fit_boot$betaHat[r, ] + 1.96*sqrt(diag(fit_boot$betaHat_var[, ,r])) * sqrt(n / (n-1))
      
      # naive CIs for averaging (remove the multiplying the variance by 1.2 correction for correlation)
      lower.avg[r, ] = fit_boot$betaHat[r, ] - 1.96*sqrt(diag(fit_boot$betaHat_var[, ,r]) / 1.2) * sqrt(n / (n-1))
      upper.avg[r, ] = fit_boot$betaHat[r, ] + 1.96*sqrt(diag(fit_boot$betaHat_var[, ,r]) / 1.2) * sqrt(n / (n-1))
      
      # check whether estimate in CI
      naive_incl[r, ] <- dat_sim$beta[r, ] <= upper[r, ] & dat_sim$beta[r, ] >= lower[r, ]
    }
    
    # average of CI inclusion over reward period
    res[1, 69] <- mean( joint_incl[beta_idx, reward_period] )  # whether joint CI contains estimate
    res[1, 70] <- mean( naive_incl[beta_idx, reward_period] )  # whether pointwise CI contains estimate
    
    # calculate regression coefficient inclusion in 95% CI (across functional domain)
    joint_incl <- rowSums(joint_incl) / ncol(joint_incl)
    naive_incl <- rowSums(naive_incl) / ncol(naive_incl)
    
    # average CI coverage across regression coefficients
    res[1, 71] <- mean(joint_incl)
    res[1, 72] <- mean(naive_incl)
    
    # don't evaluate performance on intercept (so only cue effect here since one covariate)
    res[1,73] <- mean(joint_incl[-1])
    res[1,74] <- mean(joint_incl[1])
    res[1,75] <- mean(naive_incl[-1])
    
    # average of significance
    res[1, 76] <- mean( 1 * I(upper[beta_idx, reward_period] * lower[beta_idx, reward_period] > 0) )
    res[1, 77] <- mean( 1 * I(upper.joint[beta_idx, reward_period] * lower.joint[beta_idx, reward_period] > 0) )
    
    # significance of AUC
    res[1, 78] <- 1 * I(mean(upper[beta_idx, reward_period]) * mean(lower[beta_idx, reward_period]) > 0) # if upper and lower CIs are either both positive or negative, then doesn't contain 0 so significant
    res[1, 79] <- 1 * I(mean(upper.avg[beta_idx, reward_period]) * mean(lower.avg[beta_idx, reward_period]) > 0) # if upper and lower CIs are either both positive or negative, then doesn't contain 0 so significant
    
    # closed form expression for variance of average of betas
    len <- rep(1/length(reward_period), length(reward_period))
    V <- fit_boot$betaHat_var[reward_period,reward_period,beta_idx]
    V <- eigenval_trim(V)   # trim eigenvalues to ensure matrix is PSD
    avg_var <- t(len) %*% V %*% len
    # CIs
    avg_up <- mean(fit_boot$betaHat[beta_idx, reward_period]) + 1.96 * sqrt(avg_var) * sqrt(n / (n-1))
    avg_low <- mean(fit_boot$betaHat[beta_idx, reward_period]) - 1.96 * sqrt(avg_var) * sqrt(n / (n-1))
    # significance of average
    res[1, 80] <- 1 * I(avg_up * avg_low > 0) # if upper and lower CIs are either both positive or negative, then doesn't contain 0 so significant
    beta_avg <- mean( dat_sim$beta[beta_idx, reward_period] ) # average beta for cue difference
    res[1, 81] <- mean( I( beta_avg <= avg_up) & beta_avg >= mean(avg_low) )  # whether CI contains estimate
    
    # AUC beta
    res[1, 82] <- mean( I( beta_avg <= mean(upper.avg[beta_idx, reward_period]) & beta_avg >= mean(lower.avg[beta_idx, reward_period]) ) ) # whether CI contains estimate
    
    rm(beta_avg)
  }
}

# 5 Refund ####################################################

if (params_json$run_refund) {
  dat <- tibble(
    photometry = Y,
    cue = as.numeric(dat_sim$data$cue),
    ID = as.factor(dat_sim$data$ID)
  )
  
  timeStart <- Sys.time()
  # AX: unsure if this is correct
  refund_formula <- params_json$refund_formula
  
  fit_pffr <- refund::pffr(
    formula = as.formula(refund_formula),
    algorithm = "bam",
    family = "gaussian",
    bs.yindex = list(bs = "ps", k = nknots_min, m = c(2, 1)),
    data = dat
  ) 
  
  timeEnd <- Sys.time()
  
  # 5.1 Generate 95% CIs ========================================
  
  # pffr
  coef_pffr <- coef(fit_pffr, n1 = L)
  betaHat_pffr <- betaHat_pffr.var <- dat_sim$beta
  betaHat_pffr[1, ] <- as.vector(coef_pffr$smterms$`Intercept(yindex)`$value)
  betaHat_pffr[2, ] <- as.vector(coef_pffr$smterms$`cue(yindex)`$value)
  betaHat_pffr.var[1, ] <- as.vector(coef_pffr$smterms$`Intercept(yindex)`$se^2)
  betaHat_pffr.var[2, ] <- as.vector(coef_pffr$smterms$`cue(yindex)`$se^2)
  
  lower <- upper <- lower.joint <- upper.joint <- matrix(NA, nrow = nrow(dat_sim$beta), ncol = ncol(dat_sim$beta)) # initialize CIs
  joint_incl <- naive_incl <- lower # initialize inclusion indicator matrix
  
  # iterate across regression coefficients, calculate PIs and determine inclusion across fn. domain
  for(r in 1:p){
    # naive CIs
    lower[r, ] = betaHat_pffr[r, ] - 1.96*sqrt(betaHat_pffr.var[r, ])
    upper[r, ] = betaHat_pffr[r, ] + 1.96*sqrt(betaHat_pffr.var[r, ])
    
    # check whether estimate in CI
    naive_incl[r, ] <- dat_sim$beta[r, ] <= upper[r, ] & dat_sim$beta[r, ] >= lower[r, ]
  }
  
  # average CI inclusion over reward period
  res[1, 29] <- mean( naive_incl[beta_idx, reward_period] )  # whether pointwise CI contains estimate
  
  # calculate regression coefficient inclusion in 95% CI (across functional domain)
  naive_incl <- rowSums(naive_incl) / ncol(naive_incl)
  
  # average CI coverage across regression coefficients
  res[1,55] <- mean(naive_incl)
  res[1,56] <- sqrt( mean( (dat_sim$beta - betaHat_pffr)^2 ) ) # rmse of model fit
  res[1,57] <- as.numeric( difftime(timeEnd, timeStart, units="mins") ) # time to fit model
  
  # don't evaluate performance on intercept (so only cue effect here since one covariate)
  res[1, 58] <- mean(naive_incl[-1])
  res[1, 66] <- mean(naive_incl[1])
  res[1, 59] <- sqrt( mean( (dat_sim$beta[-1, ] - betaHat_pffr[-1, ])^2 ) ) # rmse of model fit
  res[1, 60] <- mean(dat_sim$beta[beta_idx, ] - betaHat_pffr[beta_idx, ]) # bias of cue term
  
  res[1, 63] <- sqrt( mean( (beta_avg - mean(betaHat_pffr[beta_idx,reward_period]))^2 ) ) # rmse of model fit
}

# 6 Summaries #################################################

# average beta
# average beta for cue difference
beta_avg <- mean(dat_sim$beta[beta_idx, reward_period]) 
# whether CI contains estimate
res$pffr_avgbeta_CI_incl <- mean(
  I(
    beta_avg <= mean(upper[beta_idx, reward_period]) & 
      beta_avg >= mean(lower[beta_idx, reward_period])
  )
) 
# if upper and lower CIs are either both positive or negative, 
# then doesn't contain 0 so significant
res$pffr_auc_signif <- 1 * 
  I(mean(upper[beta_idx, reward_period]) * 
      mean(lower[beta_idx, reward_period]) > 0) 

# average of significance
res$pffr_avgSignif <- mean(
  1 * 
    I(upper[beta_idx, reward_period] * 
        lower[beta_idx, reward_period] > 0)
)


# 7 Save to CSV on cluster #####################################################

# res$run_id <- run_id

# Write run details
res$iter <- iter
res$n_ids <- params_json$n_ids
res$knots_div <- params_json$knots_div
res$smooth_method <- params_json$smooth_method

write.csv(
  do.call(cbind, res), 
  # paste0(save_dir, sprintf("%02d_%04d", run_id, iter), '.csv'),
  paste0(save_dir, sprintf("%04d", iter), '.csv'),
  row.names = F, # col.names = F
)