if (requireNamespace("renv", quietly = TRUE)) {
  renv::activate()
} else {
  stop("Install 'renv' to load the dependecies.")
}

if ("fastFMMconc" %in% (.packages()))
  detach("package:fastFMMconc", unload = T)

remove.packages("fastFMMconc")

# if(!"fastFMMconc" %in% (.packages()))
renv::install("~/Documents/github/fastFMMconc/fastFMMconc_0.0.1.tar.gz")
renv::snapshot()
