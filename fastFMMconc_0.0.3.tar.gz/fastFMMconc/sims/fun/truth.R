# Generate ground truth models

start_all <- Sys.time()
# truth_id <- "conc_07"
args <- commandArgs(TRUE)
truth_id <- args[1]
truth_id <- "kern_01"
message("Starting truth model for ", truth_id)
set.seed(1)

# 0 Load and setup #############################################################

# Paths that end with a slash
setwd("/data/MLDSST/xinaw/fastFMMsim")
params_dir <- "params/"
data_dir <- "data/"
save_dir <- "truth/"

# if (requireNamespace("renv", quietly = TRUE)) {
#   renv::activate()
# } else {
#   stop("Install 'renv' to load the dependecies.")
# }

params_json <- jsonlite::read_json(
  paste0(params_dir, truth_id, '.json'), 
  simplifyVector = T
)

target_Hz <- params_json$target_Hz
knots_div <- params_json$knots_div
# If 1, does every other trial
trial_trim <- params_json$trial_trim
cue_period_length <- params_json$cue_period_length 
# Don't forget to convert to as.formula

# 1 Data setup #################################################################

# 1.0 Manually write variables =================================================

mouseList <- c(
  'HJ-FP-M2',
  'HJ-FP-M3',
  'HJ-FP-M4',
  'HJ-FP-F1',
  'HJ-FP-F2',
  'HJ-FP-M6',
  'HJ-FP-M7'
) 
# last day of each condition
session_max <- c(32, 27, 37, 22, 27, 22, 23) 
# c(29, 24, 32, 19, 20, 19, 24)
cue_change <- c(29, 24, 32, 19, 24, 19, 20) 
# c(15, 15, 16, 15, 16, 16, 15)
csPlus_vec <- c(15, 15, 16, 16, 15, 15, 16) 
cue_mat <- data.frame(
  id = mouseList, 
  day = cue_change, 
  cs = csPlus_vec
)

n <- length(mouseList)
preSessions <- 3 # number of days before change day
session_min <- cue_change - (preSessions + 1) # assumes this folder only has files we need
pre_min_tm <- 1 # pre_lick period
post_min_tm <- 5 # post lick period
aic_period_length <- 5 # used for AIC
trial_num <- 100 # trials per session

# Reward period described in paper
reward_period <- seq(pre_min_tm * target_Hz + 1, cue_period_length*target_Hz) 

# samples before after
Hz <- 1 / 0.008
pre_samps <- round(pre_min_tm * Hz) # samples before lick
post_samps <- round(post_min_tm * Hz) # samples after lick

# 1.1 Read and clean data ======================================================

dat <- read.csv(paste0(data_dir, params_json$data_fname))
dat$session <- as.factor(dat$session)

# trial trim to reduce computational burden
trls_reduced <- unique(dat$trial)[
  as.integer(
    round(seq(1, length(unique(dat$trial)), by = trial_trim))
  )
]
dat <- dat[dat$trial %in% trls_reduced, ] # reduce number of trials analzed
dat$id <- as.numeric(as.factor(dat$id)) # make 1:n

# number of knots
L <- ncol(dat[, (grep(paste0("^", "photometry"), colnames(dat)))])
nknots_min <- round(L / knots_div) # L = 100
nknots_min_cov <- round(L / 4)
# order data
dat_photo <- dat[order(dat$id, dat$session, dat$trial, decreasing = FALSE), ] 
# number of subjects in (potentially) reduced sample
n <- length(unique(dat_photo$id)) 
# important for stability of model
dat_photo$trial <- scale(dat_photo$trial) 

# 2 Run model ##################################################################

timeStart <- Sys.time()
fit <- fastFMMconc::fui(
  formula = as.formula(params_json$formula), 
  data = dat_photo, 
  family = params_json$family, 
  var = params_json$var, 
  analytic = params_json$analytic,
  parallel = params_json$parallel,
  silent = params_json$silent,
  smooth_method = params_json$smooth_method,
  seed = params_json$seed,
  n_cores = params_json$n_cores,
  non_neg = params_json$non_neg,
  nknots_min = nknots_min, 
  nknots_min_cov = nknots_min_cov,
  MoM = params_json$MoM,
  concurrent = params_json$concurrent, 
  design_mat = T, 
  residuals = T, 
  randeffs = T
)
timeEnd <- Sys.time()
end_all <- Sys.time()

# Save fit
saveRDS(fit, paste0(save_dir, truth_id, ".RDS"))

# Save time to run
message(
  "Truth model:", 
  as.numeric(difftime(timeEnd, timeStart, units = "mins"))
)
message(
  "Total time:", 
  as.numeric(difftime(end_all, start_all, units = "mins"))
)
        
