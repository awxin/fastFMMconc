# fLME data simulation ######################################################### 

#' @param I (int) Number of clusters. 
#' @param J Mean number of trials for each cluster. 
#' @param rand_scale Constant to multiple the random effects
#' @param sigma_eps Standard deviation of the noise
#' @param y_name Name of output
#' @param x_name Name of functional covariate
#' @param return_fixed Whether to return the fixed effects matrix
#' @param asis_cols Whether to return functional covariates in matrix columns

synthesize_data <- function(
  I, 
  J, 
  rand_scale, 
  sigma_eps,
  y_name = "y", 
  x_name = "x", 
  return_fixed = F, 
  asis_cols = F
) {
  J_list <- rpois(I, J)
  n <- sum(J_list)
  
  # Functional covariate generation
  X <- replicate(n, fun_cov())
  
  # Fixed effects
  fixed_fx <- X * beta_1()
  fixed_fx <- fixed_fx + beta_0()
  
  # Random effects
  g_0 <- do.call(
    cbind, 
    lapply(
      1:I, 
      function(i) 
        replicate(J_list[i], gamma_0())
    )
  )
  g_1 <- do.call(
    cbind, 
    lapply(
      1:I, 
      function(i) {
        replicate(J_list[i], gamma_1())
      }
    )
  )
  if (!is.numeric(g_0)) {
    rand_fx <- as.numeric(g_0) + X * as.numeric(g_1)
    rand_fx <- matrix(rand_fx, ncol = n)
  } else {
    rand_fx <- g_0 + X * g_1
  }
  
  # Scale rand_fx
  rand_fx <- rand_scale * rand_fx
  
  # Add together signal and noise
  # Recall length(fixed_fx) == nrow(fixed_fx) * ncol(fixed_fx)
  synth <- fixed_fx + rand_fx + rnorm(length(fixed_fx), sd = sigma_eps)
  
  
  L <- nrow(synth)
  if (asis_cols) {
    df <- data.frame(matrix(NA, nrow = ncol(X), ncol = 2))
    colnames(df) <- c(x_name, y_name)
    df[x_name] <- I(t(X))
    df[y_name] <- I(t(synth))
  } else {
    # Transpose, make a data.frame, add columns for trial and cluster
    df <- data.frame(t(X), t(synth))
    colnames(df) <- c(
      paste0(x_name, "_", 1:L), 
      paste0(y_name, "_", 1:L)
    )
  }
  
  df$id <- as.factor(rep(1:I, J_list))
  df$trial <- sequence(J_list)
  
  # Return the fixed effects and the synthetic data
  if (!return_fixed) fixed_fx <- NULL
  list(
    data = df, 
    beta = rbind(beta_0(), beta_1()), 
    fixed_fx = fixed_fx
  )
}
